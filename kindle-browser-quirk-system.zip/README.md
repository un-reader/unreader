# Kindle Browser Quirk System Plugin

A portable plugin and skill package structured around the open **Agent Skills** (`SKILL.md`) format for compatibility across **Claude** (Claude Code / plugins) and **ChatGPT** (Skills / plugins / Codex).

## Structure

- `.claude-plugin/plugin.json` & `plugin.json`: Plugin manifest declaring bundled skills.
- `skills/kindle-browser-quirks/SKILL.md`: Core skill instructions and activation metadata.
- `skills/kindle-browser-quirks/references/compatibility.md`: Reference documentation loaded on demand.

## Usage Notes

- If you have the original text of `rekindle-dev/SKILL.md`, `rekindle-dev/references/compatibility.md`, `skills/SKILL.md`, and `skills/references/compatibility.md` from `kindle-browser-quirk-system.zip`, paste or merge their exact details into `skills/kindle-browser-quirks/SKILL.md` and `skills/kindle-browser-quirks/references/compatibility.md`.
