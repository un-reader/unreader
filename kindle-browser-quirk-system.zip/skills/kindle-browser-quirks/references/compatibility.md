# Kindle Browser Compatibility & Quirks Reference

> Note: Replace or merge this scaffold with the contents of `compatibility.md` from `kindle-browser-quirk-system.zip` if you have the extracted text available.

## Common Quirk Areas

- **Rendering & E-Ink Display:** Avoid rapid layout thrashing, subtle low-contrast grays, and micro-animations that cause ghosting or flicker.
- **CSS & Layout:** Test fixed positioning, flexbox/grid edge cases, custom web fonts, and viewport scaling carefully.
- **JavaScript & Web APIs:** Guard modern browser APIs with feature detection and provide server-rendered or plain-HTML fallbacks where needed.
- **Navigation & State:** Account for full-page reloads, history quirks, and constrained memory/CPU budgets.
