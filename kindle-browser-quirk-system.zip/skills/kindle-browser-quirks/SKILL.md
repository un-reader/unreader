---
name: kindle-browser-quirks
description: Use when diagnosing, designing, or implementing web pages, layouts, scripts, or reader experiences that must work reliably in the Amazon Kindle experimental browser and e-ink rendering quirks.
---

# Kindle Browser Quirk System

Use this skill when building, debugging, or auditing content and interfaces targeting Kindle devices and their built-in browser engine.

## Workflow

1. **Identify the Target Environment & Quirk Category**
   - Determine whether the issue involves e-ink display refresh/contrast, CSS layout/viewport behavior, JavaScript API limitations, navigation/history quirks, or asset/network constraints.
2. **Consult Compatibility Reference**
   - Read `references/compatibility.md` for device/firmware nuances, known workarounds, and fallbacks before proposing changes.
3. **Apply Progressive Fallbacks**
   - Prefer semantic HTML, predictable layout flows, high-contrast styling, and graceful degradation over heavy client-side scripts or rapid animations.
4. **Verify & Document**
   - Summarize affected Kindle behaviors, the chosen mitigation, and any trade-offs on standard desktop/mobile browsers.

## Reference Files

- `references/compatibility.md`: Detailed Kindle browser compatibility matrix, rendering quirks, and tested workarounds.
